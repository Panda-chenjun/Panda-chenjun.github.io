#include<bits/stdc++.h>
using namespace std;
void _main(){
	
}
int main(){
	int t;
	cin>>t;
	while(t--){
		_main();
		cout<<"\n";
	}
}